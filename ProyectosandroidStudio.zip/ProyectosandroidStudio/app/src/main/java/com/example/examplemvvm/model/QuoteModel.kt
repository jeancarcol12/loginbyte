package com.example.examplemvvm.model

class QuoteModel (val quote:String, val author:String){

}